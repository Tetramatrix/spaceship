###################
#Installation Note#
###################


This game is designed to work with Windows XP.


If the game is not working:

1) Install OpenAL (doubleclick OpenALwEAX.exe)
2) Install OpenGL (copy opengl32.dll to windows/system32/ folder)

Restart the game!

If the game is still not working:

1) Install OpenAL 1.1 Beta (copy OpenAL11BetaDLL/OpenAL32.dll to windows/system32/ folder)

Restart the game!


