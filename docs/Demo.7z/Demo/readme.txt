###########
#Spaceship#
###########

In the future the aliens are about to conquer the earth. You are a skilled spaceship pilot and the last hope of mankind. Explore the asteroidbelt between Mars and Jupiter and destroy all the aliens. Try to avoid the asteroids, they can destroy your spaceship. You have only one minute. Good Luck!


Gamekeys:
---------

Cursor-left  = Acceleration 
Cursor-right = Brake
Cursor-top   = Up
Cursor-down  = Down
Space        = Fire (hold down for continuos fire)

S = Start
P = Pause
H = Highscore


2005, Copyright by Chi Hoang, E-Mail: chibo@gmx.de
